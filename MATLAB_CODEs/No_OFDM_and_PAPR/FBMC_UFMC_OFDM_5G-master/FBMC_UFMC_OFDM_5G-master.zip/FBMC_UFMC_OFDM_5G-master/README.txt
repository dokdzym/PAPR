spectralefficiency.m contains spectral eff. of OFDM,FBMC,UFMC.

OFDM_BER.m contains BER VS SNR of OFDM

FMBC_Calculations contains FBMC related parameters with comparison to ofdm
UFMC_Calculations contains UFMC realated parameters compared to OFDM