# Clipping-vs-weighted-OFDM
Clipping vs weighted OFDM for PAPR reduction

In this matlab code we are comparing the efficiency of Weighted OFDM algorithm to Clipping algorithm for reduction of Peak amplitude to Power Ratio (PAPR) through simulations
